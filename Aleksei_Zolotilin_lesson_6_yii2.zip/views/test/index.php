<h1>Test page</h1>
<?php
/** @var $model app\models\Product */
?>

<?= $test ?>